package com.ty.food.util;

public interface Tax {
	double CGST = 12;
	double SGST = 8;
}
